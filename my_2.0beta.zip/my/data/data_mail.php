<?php
if(!defined('IN_UCHOME')) exit('Access Denied');
$_SGLOBAL['mail']=Array
	(
	'mailsend' => 1,
	'maildelimiter' => '0',
	'mailusername' => 1,
	'server' => '',
	'port' => '',
	'auth' => '0',
	'from' => '',
	'auth_username' => '',
	'auth_password' => ''
	)
?>