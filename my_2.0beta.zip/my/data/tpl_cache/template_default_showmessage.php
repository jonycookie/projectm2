<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('template/default/showmessage|template/default/header|template/default/footer', '1250583241', 'template/default/showmessage');?><?php $_TPL['nosidebar']=1; ?>
<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($space) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?> - Powered by UCenter Home</title>
<script type="text/javascript" src="script/cookie.js"></script>
<script type="text/javascript" src="script/common.js"></script>
<script type="text/javascript" src="script/menu.js"></script>
<script type="text/javascript" src="script/ajax.js"></script>
<script type="text/javascript" src="script/face.js"></script>
<script type="text/javascript" src="script/manage.js"></script>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />
<link rel="stylesheet" type="text/css" href="style/style.css" />
<?php if($_TPL['css']) { ?>
<link rel="stylesheet" type="text/css" href="style/<?=$_TPL['css']?>.css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<style type="text/css">
<?=$_SGLOBAL['space_css']?>
</style>
<?php } ?>
</head>
<body>

<div id="append_parent"></div>
<div id="ajaxwaitid"></div>

<!-- toolbar -->
<div id="toolbar">
<div class="toolbarwarp">
<h1 class="logo"><a href="index.php"><img src="template/<?=$_SCONFIG['template']?>/image/logo.gif" alt="<?=$_SCONFIG['sitename']?>" /></a></h1>
<?php if($_SGLOBAL['supe_uid']) { ?>
<ul class="s_nav">
<li><a href="space.php?do=home">首页</a></li>
<li class="dropmenu" id="m_setting" onmouseover="showMenu(this.id)"><a href="space.php?uid=<?=$_SGLOBAL['supe_uid']?>" class="login_thumb"><?php echo avatar($_SGLOBAL[supe_uid]); ?></a> <a href="cp.php">设置</a></li>
<li class="dropmenu" id="m_my" onmouseover="showMenu(this.id)"><a href="space.php">我的</a></li>
<li class="dropmenu" id="m_friend" onmouseover="showMenu(this.id)"><a href="cp.php">好友</a></li>
<li class="dropmenu" id="m_inbox" onmouseover="showMenu(this.id)"><a href="space.php?do=pm<?php if(!empty($_SGLOBAL['member']['newpm'])) { ?>&filter=newpm<?php } ?>">消息<?php if(!empty($_SGLOBAL['member']['newpm'])) { ?>！<?php } ?></a></li>
<li class="dropmenu" id="m_channel" onmouseover="showMenu(this.id)"><a href="cp.php">频道</a></li>
</ul>

<ul id="m_setting_menu" class="dropmenu_drop" style="display:none;">
<li><a href="cp.php?ac=profile">个人资料</a></li>
<li><a href="cp.php?ac=avatar">我的头像</a></li>
<?php if($_SCONFIG['videophoto']) { ?>
<li><a href="cp.php?ac=videophoto">视频认证</a></li>
<?php } ?>
<li><a href="cp.php?ac=credit">我的积分</a></li>
<?php if($_SCONFIG['allowdomain'] && $_SCONFIG['domainroot'] && checkperm('domainlength')) { ?>
<li><a href="cp.php?ac=domain">我的域名</a></li>
<?php } ?>
<?php if($_SCONFIG['sendmailday']) { ?>
<li><a href="cp.php?ac=sendmail">邮件提醒</a></li>
<?php } ?>
<li><a href="cp.php?ac=privacy">隐私筛选</a></li>
<li><a href="cp.php?ac=theme">个性化设置</a></li>
<?php if(checkperm('admin')) { ?>
<li><a href="admincp.php">站点管理</a></li>
<?php } ?>
<?php if(checkperm('allowstat')) { ?>
<li><a href="do.php?ac=stat">趋势统计</a></li>
<?php } ?>
</ul>

<ul id="m_my_menu" class="dropmenu_drop" style="display:none;">
<li><a href="space.php">我的主页</a></li>
<li><img src="image/app/doing.gif"><a href="space.php?do=doing">记录</a></li>
<li><img src="image/app/album.gif"><a href="space.php?do=album">相册</a><em><a href="cp.php?ac=upload">上传</a></em></li>
<li><img src="image/app/blog.gif"><a href="space.php?do=blog">日志</a><em><a href="cp.php?ac=blog">发表</a></em></li>
<li><img src="image/app/poll.gif"/><a href="space.php?do=poll">投票</a><em><a href="cp.php?ac=poll">发起</a></em></li>
<li><img src="image/app/mtag.gif"><a href="space.php?do=thread">群组</a><em><a href="cp.php?ac=thread">话题</a></em></li>
<li><img src="image/app/event.gif"/><a href="space.php?do=event">活动</a><em><a href="cp.php?ac=event">发起</a></em></li>
<li><img src="image/app/share.gif"><a href="space.php?do=share">分享</a></li>
<li><img src="image/app/topic.gif"><a href="space.php?do=topic">热闹</a></li>
<li><a href="space.php">我的什么</a></li>
<li><a href="cp.php?ac=invite">邀请</a></li>
<li><a href="cp.php?ac=task">任务</a></li>
<li><a href="cp.php?ac=magic">道具</a></li>
<li><a href="cp.php">设置</a></li>
<li><a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">退出</a></li>
</ul>

<ul id="m_friend_menu" class="dropmenu_drop" style="display:none;">
<li><a href="space.php?uid=1&do=friend">好友列表</a></li>
<li><a href="cp.php?ac=friend&op=search">查找好友</a></li>
<li><a href="cp.php?ac=friend&op=find">可能认识的人</a></li>
<li><a href="cp.php?ac=invite">邀请好友</a></li>
<li><a href="cp.php?ac=friend&op=request">好友请求</a></li>
<li><a href="space.php?do=top">排行榜</a></li>
</ul>

<ul id="m_inbox_menu" class="dropmenu_drop" style="display:none;">
<li><a href="space.php?do=pm"><span>短消息</span></a></li>
<li><a href="space.php?do=notice"><span>通知</span></a></li>
<li><a href="cp.php?ac=pm">发短消息</a></li>
</ul>


<ul id="m_channel_menu" class="dropmenu_drop" style="display:none;">
<li><a href="network.php">随便看看</a></li>
<li><a href="help.php">帮助</a></li>
<?php if($_SGLOBAL['appmenu']) { ?>
<li><a target="_blank" href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php } ?>
</ul>
<?php } else { ?>
<ul class="s_nav">
<li><a href="/">首页</a></li>
<li class="dropmenu" id="m_login" onmouseover="showMenu(this.id)"><a href="do.php?ac=<?=$_SCONFIG['login_action']?>">登录</a></li>
<li><a href="do.php?ac=<?=$_SCONFIG['register_action']?>">注册</a></li>
</ul>
<div id="m_login_menu" class="dropmenu_drop" style="display:none;">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p>用户名</p>
<p><input type="text" name="username" id="username" class="t_input" size="25" value="" /></p>
<p>密码</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /> <a href="do.php?ac=lostpasswd">忘记密码?</a></p>
<p><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>
</div>
<?php } ?>


<div class="">
<form method="get" action="space.php">
<input name="searchkey" value="" size="15" class="t_input" type="text">
<select name="do">
<option value="blog">日志</option>
<option value="album">相册</option>
<option value="poll">投票</option>
<option value="thread">话题</option>
<option value="event">活动</option>
</select>
<input class="submit" type="submit" value="搜索" name="searchsubmit"/>
</form>
</div>
</div>
</div>




<div id="header">
<?php if($_SGLOBAL['ad']['header']) { ?><div id="ad_header"><?php adshow('header'); ?></div><?php } ?>
<div class="headerwarp">
<div id="nav">
<ul>
<li><a href="space.php?uid=<?=$space['uid']?>&do=doing">记录</a><?php if($space['doingnum']) { ?><em>(<?=$space['doingnum']?>)</em><?php } ?></li>
<li><a href="space.php?uid=<?=$space['uid']?>&do=blog"> 日志</a><?php if($space['blognum']) { ?><em>(<?=$space['blognum']?>)</em><?php } ?></li>
<li><a href="space.php?uid=<?=$space['uid']?>&do=album">相册</a><?php if($space['albumnum']) { ?><em>(<?=$space['albumnum']?>)</em><?php } ?></li>
<li><a href="space.php?uid=<?=$space['uid']?>&do=poll"> 投票</a><?php if($space['pollnum']) { ?><em>(<?=$space['pollnum']?>)</em><?php } ?></li>
<li><a href="space.php?uid=<?=$space['uid']?>&do=thread"> 群组</a><?php if($space['threadnum']) { ?><em>(<?=$space['threadnum']?>)</em><?php } ?></li>
<li><a href="space.php?uid=<?=$space['uid']?>&do=event"> 活动</a><?php if($space['eventnum']) { ?><em>(<?=$space['eventnum']?>)</em><?php } ?></li>
<li><a href="space.php?uid=<?=$space['uid']?>&do=share"> 分享</a><?php if($space['sharenum']) { ?><em>(<?=$space['sharenum']?>)</em><?php } ?></li>
<li><a href="space.php?uid=<?=$space['uid']?>&do=topic"> 热闹</a></li>
<li><a href="space.php?uid=<?=$space['uid']?>&do=friend">好友</a><?php if($space['friendnum']) { ?><em>(<?=$space['friendnum']?>)</em><?php } ?></li>
<li><a href="space.php?uid=<?=$space['uid']?>&do=wall">留言</a><?php if($space['wallnum']) { ?><em>(<?=$space['wallnum']?>)</em><?php } ?></li>
</ul>
</div>
</div>
</div>

<div id="wrap">

<div id="main">
<div id="mainarea">
<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>

<?php } ?>

<div class="showmessage">
<caption>
<h2>信息提示</h2>
</caption>
<p><?=$message?></p>
<p class="op">
<?php if($url_forward) { ?>
<a href="<?=$url_forward?>">页面跳转中...</a>
<?php } else { ?>
<a href="javascript:history.go(-1);">返回上一页</a> | 
<a href="index.php">返回首页</a>
<?php } ?>
</p>
</div>
<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
</div>
<!--/main-->
<?php } ?>

<div id="footer" title="<?php echo debuginfo(); ?>">
<?php if($_TPL['templates']) { ?>
<div class="chostlp" title="切换风格"><img id="chostlp" src="<?=$_TPL['default_template']['icon']?>" onmouseover="showMenu(this.id)" alt="<?=$_TPL['default_template']['name']?>" /></div>
<ul id="chostlp_menu" class="chostlp_drop" style="display: none">
<?php if(is_array($_TPL['templates'])) { foreach($_TPL['templates'] as $value) { ?>
<li><a href="cp.php?ac=common&op=changetpl&name=<?=$value['name']?>" title="<?=$value['name']?>"><img src="<?=$value['icon']?>" alt="<?=$value['name']?>" /></a></li>
<?php } } ?>
</ul>
<?php } ?>

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2009 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>

<?php if($_SGLOBAL['supe_uid']) { ?>
<ul id="membernotemenu_menu" class="dropmenu_drop" style="display:none;">
<?php $member = $_SGLOBAL['member']; ?>
<?php if($member['notenum']) { ?><li><img src="image/icon/notice.gif" width="16" alt="" /> <a href="space.php?do=notice"><strong><?=$member['notenum']?></strong> 个新通知</a></li><?php } ?>
<?php if($member['pokenum']) { ?><li><img src="image/icon/poke.gif" alt="" /> <a href="cp.php?ac=poke"><strong><?=$member['pokenum']?></strong> 个新招呼</a></li><?php } ?>
<?php if($member['addfriendnum']) { ?><li><img src="image/icon/friend.gif" alt="" /> <a href="cp.php?ac=friend&op=request"><strong><?=$member['addfriendnum']?></strong> 个好友请求</a></li><?php } ?>
<?php if($member['mtaginvitenum']) { ?><li><img src="image/icon/mtag.gif" alt="" /> <a href="cp.php?ac=mtag&op=mtaginvite"><strong><?=$member['mtaginvitenum']?></strong> 个群组邀请</a></li><?php } ?>
<?php if($member['eventinvitenum']) { ?><li><img src="image/icon/event.gif" alt="" /> <a href="cp.php?ac=event&op=eventinvite"><strong><?=$member['eventinvitenum']?></strong> 个活动邀请</a></li><?php } ?>
<?php if($member['myinvitenum']) { ?><li><img src="image/icon/userapp.gif" alt="" /> <a href="space.php?do=notice&view=userapp"><strong><?=$member['myinvitenum']?></strong> 个应用消息</a></li><?php } ?>
</ul>
<?php } ?>

<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script type="text/javascript" src="script/couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?>
<?php ob_out();?>