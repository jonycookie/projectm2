<?PHP exit;?>	2009-11-13 10:28:13		127.0.0.1		/usercp.php	username=admin&password=admin
