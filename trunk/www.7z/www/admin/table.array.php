<?php
/**
 * @package iCMS V3.1
 * @copyright 2007-2009, iDreamSoft
 * @license http://www.idreamsoft.cn iDreamSoft
 * @author coolmoo <idreamsoft@qq.com>
 */
$tabledb=array(
	DB_PREFIX.'config',
	DB_PREFIX.'article',
	DB_PREFIX.'articledata',
	DB_PREFIX.'catalog',
	DB_PREFIX.'comment',
	DB_PREFIX.'advertise',
	DB_PREFIX.'contentype',
	DB_PREFIX.'message',
	DB_PREFIX.'field',
	DB_PREFIX.'model',
	DB_PREFIX.'file',
	DB_PREFIX.'page',
	DB_PREFIX.'keywords',
	DB_PREFIX.'tags',
	DB_PREFIX.'links ',
	DB_PREFIX.'admin',
	DB_PREFIX.'members',
	DB_PREFIX.'group',
	DB_PREFIX.'search',
);
?>