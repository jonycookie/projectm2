<?php error_reporting(iCMS_TPL_BUG?E_ALL ^ E_NOTICE:0);!defined('iCMS') && exit('What are you doing?');?>
<script type="text/javascript" src="<?php echo $this->_vars['site']['url']; ?>/javascript/jquery.js"></script>
<script type="text/javascript" src="<?php echo $this->_vars['site']['url']; ?>/javascript/function.js"></script>
