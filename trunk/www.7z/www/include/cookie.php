<?php
/**
 * @package iCMS V3.1
 * @copyright 2007-2009, iDreamSoft
 * @license http://www.idreamsoft.cn iDreamSoft
 * @author coolmoo <idreamsoft@qq.com>
 */
// cookie 作用域(cookie domain) EXP:'iDreamSoft.cn';
$_iGLOBAL['cookie']['domain']	= '';
// cookie 作用路径(cookie path)
$_iGLOBAL['cookie']['path']		= '/';
//cookie前缀
$_iGLOBAL['cookie']['prename']	= 'iDreamSoft_';
//31536000
$_iGLOBAL['cookie']['time']		=86400;
?>