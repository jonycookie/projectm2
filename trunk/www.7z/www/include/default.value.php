<?php
$sources=array(
	'0' => 'idreamsoft.cn',
	'1' => '网易 163.com',
	'2' => '腾讯 qq.com',
	'3' => 'idreamsoft.cn',
	'4' => '网易 163.com',
	'5' => '腾讯 qq.com',
	'6' => 'idreamsoft.cn',
	'7' => '网易 163.com',
	'8' => '腾讯 qq.com',
	'9' => 'idreamsoft.cn',
	'10' => '网易 163.com',
	'11' => '腾讯 qq.com',
	'12' => 'idreamsoft.cn',
	'13' => '网易 163.com',
	'14' => '腾讯 qq.com',
	'15' => 'idreamsoft.cn',
	'16' => '网易 163.com',
	'17' => '腾讯 qq.com',
	'18' => 'idreamsoft.cn',
	'19' => '网易 163.com',
	'20' => '腾讯 qq.com',
	'21' => 'idreamsoft.cn',
	'22' => '网易 163.com',
	'23' => '腾讯 qq.com',
);
$authors=array(
	'0' => 'admin',
	'1' => 'coolmoo',
);
$editors=array(
	'0' => 'admin',
	'1' => 'coolmoo',
);
?>