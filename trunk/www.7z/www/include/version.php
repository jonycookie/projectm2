<?php
/**
 * @package iCMS V3.1
 * @copyright 2007-2009, iDreamSoft
 * @license http://www.idreamsoft.cn iDreamSoft
 * @author coolmoo <idreamsoft@qq.com>
 */
define('iCMS_VER', '3.1.2');
define('iCMS_RELEASE', '20091101');
define('Version','V3.1.2');//当前版本
?>