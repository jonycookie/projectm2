<?php
/**
 * @package iCMS V3.1
 * @copyright 2007-2009, iDreamSoft
 * @license http://www.idreamsoft.cn iDreamSoft
 * @author coolmoo <idreamsoft@qq.com>
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>iCMS - 安装向导</title>
<link href="install.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="main"><img src="http://www.idreamsoft.cn/doc/iCMS.logo.gif"/>
  <p align="center" class="title">iCMS V3.1 安装向导</p>
  <p class="title">&nbsp;</p>
  <table width="98%" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="50%" height="25" align="center"><a href="install.php">全新安装</a></td>
      <td align="center"><a href="update.php">升级</a></td>
    </tr>
  </table>
  <hr size="1" noshade="noshade" />
  <p align="right"><a href="http://www.idreamsoft.cn" target="_blank">Welcome to iDreamSoft</a></p>
</div>
<strong>Powered by <a href="http://www.idreamsoft.cn" target="_blank">iCMS</a> V3.1 &copy; 2007-2009 </strong>
</body>
</html>
