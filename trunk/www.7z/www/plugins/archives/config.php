<?php
/*
 * @package iCMS V3.1
 * @copyright 2007-2009, iDreamSoft
 * @license http://www.idreamsoft.cn iDreamSoft
 * @author coolmoo <idreamsoft@qq.com>
 *	================================
 *	Plugin Name: Archives/文章归档
 *	Plugin URI: http://www.iDreamSoft.cn
 *	Description: Archives/文章归档
 *	Version: 1.0
 *	Author: 枯木
 *	Author URI: http://G.iDreamSoft.cn
 *	TAG:<!--{iCMS:plugins name='archives'}-->
 */
!defined('iPATH') && exit('What are you doing?');
?>