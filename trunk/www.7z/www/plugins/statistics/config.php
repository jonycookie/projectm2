<?php
/*
 * @package iCMS V3.1
 * @copyright 2007-2009, iDreamSoft
 * @license http://www.idreamsoft.cn iDreamSoft
 * @author coolmoo <idreamsoft@qq.com>
 *	================================
 *	Plugin Name: Statistics/ͳ��
 *	Plugin URI: http://www.iDreamSoft.cn
 *	Description: Statistics/ͳ��
 *	Version: 1.0
 *	Author: ��ľ
 *	Author URI: http://G.iDreamSoft.cn
 *	TAG:<!--{iCMS:plugins name='statistics'}-->
 */
!defined('iPATH') && exit('What are you doing?');
?>