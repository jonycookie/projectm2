<?php
/**
 * @package iCMS V3.1
 * @copyright 2007-2009, iDreamSoft
 * @license http://www.idreamsoft.cn iDreamSoft
 * @author coolmoo <idreamsoft@qq.com>
 */
!defined('iPATH') && exit('What are you doing?'); 
?>
<ul class="shortcut-buttons-set">
  <li><a class="shortcut-button new-article" href="usercp.php?do=article&operation=add"><span class="png_bg"> 撰写新文章 </span></a></li>
<?php /*  <li><a class="shortcut-button upload-image" href="usercp.php?do=file&operation=upload"><span class="png_bg"> 上传图片</span></a></li>
  <li><a class="shortcut-button new-page" href="#"><span class="png_bg"> New Page </span></a></li>
  <li><a class="shortcut-button add-event" href="#"><span class="png_bg"> Add an Event </span></a></li>
  <li><a class="shortcut-button manage-comments" href="#messages" rel="modal"><span class="png_bg"> Open Modal </span></a></li>
*/?>
</ul>
<div class="clear"></div>